
class ApiPath{
  // static const String baseUrl ="https://developmentalphawizz.com/Kabadi/api";

  static const String baseUrl ="https://developmentalphawizz.com/e_gate/Api/";
  static const String imgUrl = 'https://developmentalphawizz.com/e_gate/uploads/';
  static const String imgUrl1 = 'https://developmentalphawizz.com/e_gate/uploads/profile_pics/';

  static const String login = baseUrl +'login';
  static const String update_profile = baseUrl+'update_profile';
  static const String get_profile = baseUrl+ 'get_profile';
  static const String show_details = baseUrl+ 'show_details';

}