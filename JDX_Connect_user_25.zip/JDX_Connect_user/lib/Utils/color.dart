import 'package:flutter/material.dart';

//Colors
// final Color primaryColor = Color(0xFF5B2187);
final Color primaryColor = Color(0xFFBF2331 );
final Color Secondry = Color(0xFFF2B304 );
final Color whiteColor = Color(0xFFFFFFFF);
final Color splashcolor = Color(0xFFDDEDFA);
final Color greyColor = Color(0xFFBEBEBE);
final Color greyColor1 = Color(0xFFA4A4A4);
final Color greyColor3 = Color(0xFF919191);
final Color profileBg = Color(0xFFF6F6F6);
final Color greyColor2 = Color(0xFF747474);
final Color purpleColor = Color(0xFFECE1FF);

//TextStyles
final TextStyle buttonTextStyle = TextStyle(fontSize: 18,fontWeight: FontWeight.bold, color: Colors.black);
